HOW TO RUN THIS PROGRAM STEP BY STEP

download the folder from GitHub

1.Open Google colab on a specific Browser
2. DO Not create New file, Open file and choose the location you downloaded the project.
3. Once Opened Run the Code , scrol down and Click Choose file, from the folder downloaded. 
4.Now select the "Disease_symptom_and_patient_profile_dataset" file 
project will execute smoothly.